# Self-Balancing Robot — Multi-Mode Workspace

## هدف إعادة الهيكلة
تم تقسيم المشروع إلى أجزاء واضحة حتى لا تختلط دائرة الاتزان الأساسية مع ESP32 والـ remote والـ dashboard والمحاكاة. الكود القديم محفوظ في `assets/original/`، بينما الملفات التي تبدأ من التطويرات الجديدة موجودة في `firmware/` و`simulation/`.

## الأنماط الأربعة
1. **USB Direct**: Arduino Uno هو المتحكم، واللابتوب يرسل أوامر عبر USB.
2. **Arduino + ESP32 Bridge**: Arduino يحتفظ بحلقة الاتزان؛ ESP32 يستقبل Wi‑Fi ويمرر أوامر الحركة عبر UART.
3. **Arduino Standalone**: Arduino يعمل محلياً بالـ MPU6050 وPID دون هاتف أو إنترنت.
4. **ESP32 Standalone**: بعد نقل الأسلاك فعلياً، يتولى ESP32 الحساس والمحركات وPWM والاتصال اللاسلكي. لا يتم تشغيل النمطين الثاني والرابع معاً بنفس الأسلاك.

## ترتيب العمل
- اقرأ `docs/ENGINEERING_BLUEPRINT_AR.md` قبل التوصيل.
- نفّذ `hardware/PINOUT_AND_POWER_AR.md` ثم اختبر GND والطاقة.
- ابدأ بـ Arduino فقط، ثم أضف ESP32 كجسر، ثم اختبر ESP32 المستقل بأسلاك منفصلة.
- استخدم `simulation/wokwi/diagram.json` للمراجعة البصرية، وملفات `simulation/tex/` للمخططات المفاهيمية.
- لا توصل 5V Arduino إلى GPIO في ESP32؛ استخدم تحويل مستويات UART مناسباً.

## المكتبات
المكتبات الأصلية محفوظة في `libraries/`: I2Cdev وMPU6050 وPID_v1 وLMotorController. مكتبات IR وESP32 وMQTT تُثبت فقط عند استخدام النمط المعني.

## السلامة
افصل البطارية قبل تغيير الأسلاك. استخدم مقاومة 220Ω لكل LED. لا تستخدم خرج L298N لتغذية VIN دون التحقق من اللوحة ومنظمها. HC-SR04 يحتاج حماية مستوى Echo عند توصيله إلى ESP32. لا تجعل dashboard أو MQTT يعطلان حلقة PID.
