#include <Wire.h>
#include <PID_v1.h>

#define ENA_PIN 5
#define IN1_PIN 6
#define IN2_PIN 7
#define IN3_PIN 8
#define IN4_PIN 9
#define ENB_PIN 10
#define IR_PIN 3
#define LED_1 11
#define LED_2 12
#define LED_3 13
#define LED_4 4

double input = 0;
double output = 0;
double setpoint = 0;
double Kp = 22, Ki = 140, Kd = 1.5;
PID balancePID(&input, &output, &setpoint, Kp, Ki, Kd, DIRECT);
char command = 'S';

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(ENA_PIN, OUTPUT); pinMode(IN1_PIN, OUTPUT); pinMode(IN2_PIN, OUTPUT);
  pinMode(IN3_PIN, OUTPUT); pinMode(IN4_PIN, OUTPUT); pinMode(ENB_PIN, OUTPUT);
  pinMode(IR_PIN, INPUT);
  pinMode(LED_1, OUTPUT); pinMode(LED_2, OUTPUT); pinMode(LED_3, OUTPUT); pinMode(LED_4, OUTPUT);
  balancePID.SetMode(AUTOMATIC); balancePID.SetOutputLimits(-255, 255); balancePID.SetSampleTime(10);
  Serial.println(F("Arduino balance controller ready"));
}

void loop() {
  input = readAngle();
  if (Serial.available()) command = Serial.read();
  setpoint = command == 'F' ? 3 : command == 'B' ? -3 : 0;
  balancePID.Compute();
  drive(output);
  indicators(input);
}

double readAngle() {
  Wire.beginTransmission(0x68); Wire.write(0x3B); Wire.endTransmission(false);
  Wire.requestFrom(0x68, 2, true);
  if (Wire.available() < 2) return 0;
  int16_t raw = (Wire.read() << 8) | Wire.read();
  return map(raw, -16384, 16384, -90, 90);
}

void drive(double v) {
  int pwm = constrain((int)abs(v), 0, 255);
  bool forward = v > 0;
  digitalWrite(IN1_PIN, forward); digitalWrite(IN2_PIN, !forward);
  digitalWrite(IN3_PIN, forward); digitalWrite(IN4_PIN, !forward);
  if (v == 0) { digitalWrite(IN1_PIN, LOW); digitalWrite(IN2_PIN, LOW); digitalWrite(IN3_PIN, LOW); digitalWrite(IN4_PIN, LOW); }
  analogWrite(ENA_PIN, pwm); analogWrite(ENB_PIN, pwm);
}

void indicators(double a) {
  digitalWrite(LED_1, a > 15 || a < -15);
  digitalWrite(LED_2, a > -2 && a < 2);
  digitalWrite(LED_3, a > -2 && a < 2);
  digitalWrite(LED_4, a > 15 || a < -15);
}
