#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <PID_v1.h>

#define SDA_PIN 21
#define SCL_PIN 22
#define MPU_INT 19
#define IN1_PIN 32
#define IN2_PIN 33
#define IN3_PIN 25
#define IN4_PIN 26
#define ENA_PIN 27
#define ENB_PIN 14
#define IR_PIN 18
#define MODE_PIN 35
#define LED_1 4
#define LED_2 16
#define LED_3 17
#define LED_4 23

double input=0, output=0, setpoint=0;
double Kp=22, Ki=140, Kd=1.5;
PID balancePID(&input,&output,&setpoint,Kp,Ki,Kd,DIRECT);

void setup() {
  Serial.begin(115200); Wire.begin(SDA_PIN,SCL_PIN); pinMode(MODE_PIN,INPUT_PULLUP);
  pinMode(IN1_PIN,OUTPUT); pinMode(IN2_PIN,OUTPUT); pinMode(IN3_PIN,OUTPUT); pinMode(IN4_PIN,OUTPUT);
  ledcAttach(ENA_PIN,20000,8); ledcAttach(ENB_PIN,20000,8);
  balancePID.SetMode(AUTOMATIC); balancePID.SetOutputLimits(-255,255); balancePID.SetSampleTime(10);
  Serial.println(F("ESP32 standalone controller ready"));
}

void loop() {
  input=readAngle();
  balancePID.Compute();
  drive(output);
  publishTelemetry();
}

double readAngle() { return 0; }
void drive(double v) {
  bool f=v>0; int p=constrain((int)abs(v),0,255);
  digitalWrite(IN1_PIN,f); digitalWrite(IN2_PIN,!f); digitalWrite(IN3_PIN,f); digitalWrite(IN4_PIN,!f);
  ledcWrite(ENA_PIN,p); ledcWrite(ENB_PIN,p);
}
void publishTelemetry() { static uint32_t t=0; if(millis()-t>100){t=millis(); Serial.printf("angle=%.2f output=%.2f\n",input,output);} }
