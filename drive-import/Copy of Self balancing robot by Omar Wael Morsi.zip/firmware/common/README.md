# Shared firmware contract

Commands: F forward, B backward, L left, R right, S stop/hold. Telemetry fields: angle, output, motor direction, system state. Cloud messages must never block the PID loop.
