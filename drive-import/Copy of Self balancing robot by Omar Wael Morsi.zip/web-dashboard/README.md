# Web Dashboard architecture

Use an external Node.js/MQTT or WebSocket backend for public access. ESP32 publishes telemetry and subscribes to movement commands. Keep a tiny local AP page as emergency fallback only. D-pad commands are F/B/L/R/S; expose a visible emergency stop and authentication/rate limiting before public deployment.
