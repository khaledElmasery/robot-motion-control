# Pinout والطاقة

| الوظيفة | Arduino Uno | ESP32 standalone | ملاحظة |
|---|---:|---:|---|
| MPU6050 VCC | 3.3V أو حسب الموديول | 3.3V | تحقق من اللوحة |
| MPU6050 GND | GND | GND | أرضي مشترك في bridge |
| SCL | A5 | GPIO22 | I2C |
| SDA | A4 | GPIO21 | قد يختلف حسب اللوحة |
| INT | D2 | GPIO19 | interrupt |
| L298N IN1/IN2 | D6/D7 | GPIO32/33 | اتجاه المحرك الأيسر |
| L298N IN3/IN4 | D8/D9 | GPIO25/26 | اتجاه المحرك الأيمن |
| ENA/ENB | D5/D10 | GPIO27/14 | PWM |
| IR OUT | D3 | GPIO18 | افحص مستوى الإشارة |
| LEDs 1..4 | D4,D11,D12,D13 | GPIO13,12,14,27 | 220Ω لكل LED |
| Display DAT/CLK/LATCH | A1,A2,A3 | GPIO4,16,17 | لا تفترض FD650 قبل القياس |
| HC-SR04 Trig/Echo | غير محجوزين؛ اختر بعد اختبار pin budget | اقترح GPIO5/34 مع level shift | Echo ليس 5V tolerant |

## الطاقة
موجب البطارية إلى 12V input في L298N عبر المفتاح، والسالب إلى GND. اربط GND Arduino وESP32 وMPU6050 وIR وLEDs والشاشة. استخدم buck converter مناسباً للـ 5V/3.3V. لا توصل 12V إلى Arduino أو ESP32 أو MPU6050. عند UART بين 5V Arduino و3.3V ESP32 استخدم محول مستويات، ولا تصل TX Arduino مباشرة إلى RX ESP32.

## المحركات
محركان: الأيسر OUT1/OUT2 والأيمن OUT3/OUT4. أربعة محركات: محركا كل جانب على التوازي فقط إذا كان تيار L298N مناسباً؛ ممنوع التوالي لأنه يقسم الجهد ويضعف العزم.
