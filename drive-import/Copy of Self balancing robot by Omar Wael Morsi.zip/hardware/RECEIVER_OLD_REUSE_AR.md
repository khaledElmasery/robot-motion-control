# إعادة استخدام receiver القديم

## لوحة SUPER GOLD X3 SG-555
- افحص الوسوم: ADD/5V، GND، DAT، CLK، IR.
- FD650 مذكور على اللوحة، لكن بروتوكول الشاشة يجب تأكيده من datasheet أو logic analyzer قبل كتابة driver.
- الشاشة: ابدأ بقياس 5V/GND، ثم CLK/DAT، ولا تتجاوز مستويات GPIO.
- IR: استخدم OUT فقط إلى D3 في Arduino أو GPIO18 في ESP32، وثبّت VCC/GND حسب الموديول.

## Remote
التقط أكواد الأزرار أولاً بمثال IRremote، ثم اربط: Up=forward، Down=back، Left/Right=turn، أرقام السرعة/الوضع. لا تُخمن الأكواد ولا تجعل أمر remote يتغلب على زر الطوارئ أو حد HC-SR04.
