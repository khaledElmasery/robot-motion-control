# Wokwi

The diagram covers MPU6050 and four LEDs. L298N/motor parts from the supplied draft may require a custom Wokwi part; validate the pin model before treating simulation as electrical proof.
